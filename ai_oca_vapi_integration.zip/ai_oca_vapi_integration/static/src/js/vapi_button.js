/** @odoo-module **/

import { Component, onMounted } from "@odoo/owl";
import { jsonRpc } from "@web/core/network/rpc_service";

function toOdooDatetime(dateObj) {
    const pad = (n) => (n < 10 ? "0" + n : n);
    return (
        dateObj.getFullYear() +
        "-" + pad(dateObj.getMonth() + 1) +
        "-" + pad(dateObj.getDate()) + " " +
        pad(dateObj.getHours()) +
        ":" + pad(dateObj.getMinutes()) +
        ":" + pad(dateObj.getSeconds())
    );
}

export class VapiButton extends Component {
    setup() {
        console.log("🌟 VapiButton setup!");
        onMounted(() => this.loadSdkAndInit());
    }

    async loadSdkAndInit() {
        console.log("🌟 VapiButton loadSdkAndInit");
        const config = await jsonRpc("/ai_oca_vapi_integration/widget_config", "call", {});

        if (!document.getElementById("vapi-sdk")) {
            const script = document.createElement("script");
            script.src = "/ai_oca_vapi_integration/static/src/js/vapi_sdk.js";
            script.id = "vapi-sdk";
            script.defer = true;
            script.async = true;
            document.head.appendChild(script);
            await new Promise(resolve => {
                script.onload = resolve;
            });
        }

        this.initVapi(config.result);
    }

    initVapi(config) {
        console.log("🌟 VapiButton initVapi", config);
        const instance = window.vapiSDK.run({
            apiKey: config.api_key,
            assistant: config.assistant_id,
            assistantOverrides: {
                firstMessage: `Hola ${config.userName}, ¿cómo estás?`,
                variableValues: {
                    userData: config.userData,
                    companyData: config.companyData,
                    fechaHora: new Date().toLocaleDateString(),
                },
                metadata: {},
            },
        });

        let logId = null;
        let start = null;

        instance.on("call-start", () => {
            start = new Date();
            const callId = "call_" + Date.now();
            jsonRpc("/web/dataset/call_kw/vapi.log/create", "call", {
                model: "vapi.log",
                method: "create",
                args: [{
                    user_id: config.userId,
                    start_time: toOdooDatetime(start),
                    state: "started",
                    call_id: callId,
                }],
                kwargs: {},
            }).then((result) => {
                logId = result;
            });
        });

        instance.on("message", (message) => {
            if (message.type === "transcript" && message.role === "user" && message.transcriptType === "final" && logId) {
                jsonRpc("/web/dataset/call_kw/vapi.log/write", "call", {
                    model: "vapi.log",
                    method: "write",
                    args: [[logId], {
                        state: "in_progress",
                        last_active: toOdooDatetime(new Date()),
                    }],
                    kwargs: {},
                });
            }
        });

        instance.on("call-end", () => {
            const end = new Date();
            if (!logId || !start) return;
            const duration = Math.floor((end - start) / 1000);
            jsonRpc("/web/dataset/call_kw/vapi.log/write", "call", {
                model: "vapi.log",
                method: "write",
                args: [[logId], {
                    end_time: toOdooDatetime(end),
                    duration,
                    state: "finished",
                }],
                kwargs: {},
            });
        });
    }
}


VapiButton.template = "ai_oca_vapi_integration.VapiButton";

console.log("✅ VapiButton setup");
