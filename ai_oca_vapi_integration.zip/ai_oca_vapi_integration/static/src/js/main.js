/** @odoo-module **/

import { VapiButton } from "./vapi_button";
import { mount, whenReady } from "@odoo/owl";

console.log("🌟 VapiButton about to mount!");

whenReady(() => {
    const root = document.createElement("div");
    document.body.appendChild(root);
    mount(VapiButton, { target: root });
});
